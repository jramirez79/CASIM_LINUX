export default {
    // draws a blue rectangle border around the collision box of a label
    draw_label_collision_boxes: false,
    // draws a green rectangle border within the texture box of a label
    draw_label_texture_boxes: false,
    // suppreses fade-in of labels
    suppress_label_fade_in: false,
    // suppress animaton of label snap to pixel grid
    suppress_label_snap_animation: false
};
